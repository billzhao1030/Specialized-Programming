public class SquareOfDigits {
    public static void main(String[] args) {
        String[] data = {"as"};
        int result = getMax(data);
        System.out.println(result);
    }

    public static int getMax(String[] data) {
        return 1;
    }
    
}